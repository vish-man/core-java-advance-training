package Books;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TestBook
{
    public static void main (String[] args) {
    	
        try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter the Book Title:");
			String bookname=sc.nextLine();
			
			System.out.println("Enter the price:");
			int price=sc.nextInt();
			sc.nextLine();
			
			
			Book obj=new Book();
			obj.setbookTitle(bookname);
			obj.setBookPrice(price);
			
			System.out.println("Description of the Book: ");
			System.out.println("Book Title :"+obj.getBookTitle());
			System.out.println("Book Price :"+obj.getBookPrice());
		}
        catch (InputMismatchException e) {
        	System.out.println("please enter the price of the book in numbers, e.g:500 :)");
        }
    }
}