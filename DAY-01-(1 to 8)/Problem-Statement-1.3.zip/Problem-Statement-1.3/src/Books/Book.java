package Books;
public class Book
{
    private String bookTitle;
    private int bookPrice;
    
    public void setbookTitle(String bookTitle)
    {
        this.bookTitle=bookTitle;
    }
    
    public String getBookTitle()
    {
        return this.bookTitle;
    }
    
    public void setBookPrice(int bookPrice)
    {
        this.bookPrice=bookPrice;
    }
    
    public int getBookPrice()
    {
        return this.bookPrice;
    }
}