import java.util.Hashtable;
import java.util.Scanner;
public class Product {

 public static void main(String[] args) {
	 
	try (Scanner prod = new Scanner(System.in)) {
		
		Hashtable<String,String> vish=new Hashtable<String,String>();
		System.out.println("enter the product id and name:");
		
		for(int i=0;i<3;i++)
		{
			vish.put(prod.next(),prod.next());
		}
		
		System.out.println("the product list is:");
		System.out.println(vish);
		
		System.out.println("enter the product id to be removed:");
		String id = prod.next();
		vish.remove(id);
		System.out.println("item removed");
		
		System.out.println("the product list is:");
		System.out.println(vish.toString());
		
		System.out.println("enter the product id to be searched:");
		String tess=prod.next();
		if(vish.containsKey(tess))
		{
			System.out.println(vish.get(tess));
		}
		else {
			System.out.println("do not exist");
		}
	}
}
}
