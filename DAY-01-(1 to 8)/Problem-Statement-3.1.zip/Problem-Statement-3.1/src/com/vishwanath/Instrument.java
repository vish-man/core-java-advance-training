package com.vishwanath;

public abstract class Instrument {
	
	public abstract void play();
}
