package com.vishwanath;

 public class MphasisString {

	    static void printRotatedString(String str)
	    {
	        int length1 = str.length();
	      
	        StringBuffer sb;
	         
	        for (int i = 0; i < length1+1; i++)
	        {
	            sb = new StringBuffer();
	             
	            int j = i;  
	            int k = 0;  
	            int length2 = str.length();
	            
	            for (int k2 = j; k2 < length2; k2++) {
	                sb.insert(k, str.charAt(j));
	                k++;
	                j++;
	            }
	      
	            
	            j = 0;
	            while (j < i)
	            {
	                sb.insert(k, str.charAt(j));
	                j++;
	                k++;
	            }
	      
	            System.out.println(sb);
	        }
	    }
	     
	 public static void main(String[] args)
	    {
	        String  str = new String("MPHASIS");
	        printRotatedString(str);
	    }
	}
