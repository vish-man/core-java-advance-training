import java.util.Scanner;

public class seriesOfSumPrevTwoNum {

   public static void main(String[] args) {

	int n = 15, firstTerm1, secondTerm2;
	
	Scanner firstTerm = new Scanner(System.in);
	   System.out.println("Enter first term: ");
	   firstTerm1 = firstTerm.nextInt();
	   
    Scanner secondTerm = new Scanner(System.in);
	   System.out.println("Enter second term: ");
	   secondTerm2 = secondTerm.nextInt();
	   
	   System.out.println("\nYou entered firstTerm as: "+firstTerm1+ ", and secondTerm as: "+secondTerm2);
		   
	 System.out.println("\nThe required series is as follows for" + n + " terms: ");

		 for (int i = 1; i <= n; ++i) {
		     
		System.out.print(firstTerm1 + "  ");

		      // compute the next term
		      int nextTerm = firstTerm1 + secondTerm2;
		        firstTerm1 = secondTerm2;
		       secondTerm2 = nextTerm;
		    }
		  }
		}