package com.vishwanath;

public class StringHandlingRegularExpressions {

		public static void main(String[] args) {
			
		String java= "JAVA is Simple";
		
  //For UpperCase Converting
		System.out.println(java.toUpperCase());
  //For LowerCase Converting	
		System.out.println(java.toLowerCase());
		
  //For Getting 1st word of letter		
		String[] words=java.split("\\s");
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
  //For Changing the Order	
		String[] words1=java.split("\\s"); 
		for(String w:words1){  
			System.out.println(w); 
		}
		
  // For Reversing the String 
		StringBuilder words2= new StringBuilder("JAVA is Simple");
		
		Object words3;
		System.out.println("String = " + words2.toString());
		StringBuilder reverseStr = words2.reverse();
		System.out.println("Reverse String = " + reverseStr.toString());
		
  //For finding Length of the string
		System.out.println("length of string " + java.length());
	}
}