package com.vishwanath;

public class medicine{
	public void displayLabel(){
		
	System.out.println("Company : Avara Pharmaceutical Company");
	System.out.println("Place : Belagavi,Karnataka");
	}
	}
class Tablet extends medicine{
	 
public void displayLabel()
{
	System.out.println("Store it in a cool dry place");
}
}

class Syrup extends medicine{
	
	public void displayLabel(){
		System.out.println("Consumption as directed by therapist");
		}
	}

class Ointment extends medicine{
	
	public void displayLabel(){
		System.out.println("For the external use only");}
	}