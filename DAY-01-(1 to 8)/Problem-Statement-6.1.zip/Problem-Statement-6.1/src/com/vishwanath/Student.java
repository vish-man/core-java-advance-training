package com.vishwanath;

import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Student {
	
 public static void main (String[] args) {
	 
	 ArrayList<String> a1=new ArrayList<String>();
      int n;
  try (Scanner tess = new Scanner(System.in)) {
	System.out.println("enter the number of students: ");
	    n=tess.nextInt();
	    
	  System.out.println("enter the student names: ");
	     
	  for(int i=0;i<n;i++){
	  	  a1.add(tess.next());
	       }
	    System.out.println("student list:");
	     for(@SuppressWarnings("unused") String a:a1){
			System.out.println("enter the name of the student to be searched:");
		    String vish=tess.next(); 
		    int position=Collections.binarySearch(a1,vish);
			System.out.println("posistion of"+vish+"is:"+position);
			
			}
   }
      catch(InputMismatchException e) {
	  System.out.println("please enter the numerical value :)");
             }
  
     }
 }