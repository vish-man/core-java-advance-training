package com.vishwanath;

public class ExpressionParser {
	
	public static void main(String[] args) {
		
	String thing= (" 23  +  45  -  (  343  /  12  ) ");
	
	String[] vish=thing.split("\\\s");
	
	for(String tess:vish){
		
		System.out.println(tess);
	}
}

}