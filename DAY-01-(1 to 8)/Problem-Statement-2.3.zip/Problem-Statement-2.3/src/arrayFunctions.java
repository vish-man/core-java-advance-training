import java.util.Arrays;

public class arrayFunctions {

	public static void main(String[] args) {
		int sum=0;
		int[] A= {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
		
		System.out.println("Length of the array is: "+A.length);
		
		  System.out.println("Original Array : "+Arrays.toString(A));     

	//for: Compute the sum of elements from index 0 to 14 and stores it at element 15 
		  for (int i=0; i<=15; i++)
				
				sum+=A[i];
					
			System.out.println("\nsum of elements upto index position 14: "+sum);
			
			 for(int i=A.length-1; i > 15; i--){
				    A[i] = A[i-1];
				   }
			 A[15] = sum;
			   System.out.println("New Array1: "+Arrays.toString(A));
			 
	           
	//for: Compute the average of all numbers and stores it at element 16             			  
			  int avg=sum/(A.length);
						
				System.out.println("\naverage of elements in the given array is: "+avg);
				
				 for(int i=A.length-1; i > 16; i--){
					    A[i] = A[i-1];
					   }
				 A[16] = avg;
				   System.out.println("New Array2: "+Arrays.toString(A));
				 
	
    //for: Identifies the smallest value from the array and stores it at element 17
		   
				   //Initialize min with first element of array.  
			        int min = A[0];  
			        
			        //Loop through the array  
			        for (int i = 0; i < A.length; i++) { 
			        	
			            //Compare elements of array with min  
			           if(A[i] <min)  
			               min = A[i];  
			        }  
			        System.out.println("\nSmallest element present in given array: " + min); 
			        
			        for(int i=A.length-1; i > 17; i--){
					    A[i] = A[i-1];
					   }
				 A[17] = min;
			        
					   System.out.println("New Array3: "+Arrays.toString(A));
					 }
	  }


