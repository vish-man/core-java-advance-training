package com.vishwanath;

import java.util.Scanner;

public class EvenFind {

	public static void main(String[] args) {

		int n=0;
		
		try (Scanner scan = new Scanner(System.in)) {
			
			System.out.println("Enter value n: ");

			n = scan.nextInt();
		}
		
		if(n>0) {
		
		System.out.println("Even Numbers from 1 to "+n+" are: ");
					
	    for(int i=1;i<=n;i++) {
	    	
	    	
	    	if(i%2==0) {
	    		
	    		System.out.println(i+"");
	    	}
	    	
	    }
		}
		else {
			System.out.println("enter the number greater than 1 :)");
			
		}
	}
}
