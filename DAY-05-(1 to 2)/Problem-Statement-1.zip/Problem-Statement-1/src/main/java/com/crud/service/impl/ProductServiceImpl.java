package com.crud.service.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.crud.exception.ResourceNotFoundException;
import com.crud.model.Product;
import com.crud.repository.ProductRepository;
import com.crud.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{
	
	private ProductRepository productRepository;

	public ProductServiceImpl(ProductRepository productRepository) {
		super();
		this.productRepository = productRepository;
	}

	@Override
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Product getProductById(long id) {
		// TODO Auto-generated method stub
		Optional<Product> product = productRepository.findById(id);
        if(product.isPresent()) {
        	return product.get();
        }
        else {
        	throw new ResourceNotFoundException("Product", "Id", "id");
        }
}

	@Override
	public Product updateProduct(Product product, long id) {
		// we need check whether product with given id is exist in DB or not 
		
		Product existingProduct = productRepository.findById(id).orElseThrow(
				()-> new ResourceNotFoundException("Product", "Id", id));
		
		existingProduct.setProductName(product.getProductName());
		existingProduct.setProductPrice(product.getProductName());
		existingProduct.setProductQuantity(product.getProductQuantity());
		
		//save existing product to DB
		productRepository.save(existingProduct);
		return existingProduct;
	}

	@Override
	public void deleteProduct(long id) {
		
		//check whether product exist in DB or not 
		productRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product", "Id", id));
		
     productRepository.deleteById(id);		
	}
}

	