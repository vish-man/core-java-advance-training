package vishwanath;

// Java program to find minimum
// number of denominations
import java.util.Vector;

class CoinChangeDemo
{

	// All denominations of Indian Currency
	static int deno[] = {1,2,5,10,20,50,100,500,2000};
	
	static int n = deno.length;

	static void findMin(int V)
	{
		// Initialize result
		Vector<Integer> ans = new Vector<>();

		// Traverse through all denomination
		for (int i = n - 1; i >= 0; i--)
		{
			// Find denominations
			while (V >= deno[i])
			{
				V -= deno[i];
				ans.add(deno[i]);
				
			}
		}

		// Print result
		for (int i = 0; i < ans.size(); i++)
		{
			System.out.print(" RS." + ans.elementAt(i)+"*1  ");
		}
	}

	// Driver code
	public static void main(String[] args)
	{
		int n = 2045;
		System.out.print("Breakdown- ");
		findMin(n);
	}
}
