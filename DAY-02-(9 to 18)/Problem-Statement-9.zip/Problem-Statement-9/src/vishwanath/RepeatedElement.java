package vishwanath;

	public class RepeatedElement {


		// this logic will calculate each element repeated how many times..
		
		static void findFrequency(int[] input, int n)
		{
			for (int i = 0; i < n; i++)
				input[i]--;

			for (int i = 0; i < n; i++)
				input[input[i] % n] += n;

			for (int i = 0; i < n; i++) {
				
				if ((input[i] / n) != 0)
					
				System.out.println((i + 1) + " occurs "+ input[i] / n + " times");
				
				// Changing the element back to original value
				input[i] = input[i] % n + 1;
			}
		}

		// this is the driver function
		public static void main(String[] args)
		{
			int[] arr= {2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 };
			int n = arr.length;
			findFrequency(arr, n);
		}
	}
