package vishwanath;

class StaircaseDemo {
		
		static int check(int tess)
		{
			if (tess <= 1)
				return tess;
			return check(tess - 1) + check(tess - 2);
		}

			static int numberOfWays(int n)
		{
			return check(n + 1);
		}

		
		public static void main(String args[])
		{
//			int n = 2;
//			int n = 3;
			int n= 45;
			System.out.println("Number of ways = " + numberOfWays(n));
		}
	} 
