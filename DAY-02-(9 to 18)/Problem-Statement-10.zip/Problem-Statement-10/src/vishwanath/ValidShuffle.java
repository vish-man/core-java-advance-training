package vishwanath;

public class ValidShuffle {

	static boolean isInterleaved(String first, String second,String third)
	{
		
		// Find lengths of the two strings
		int M = first.length(), N = second.length();

		// Let us create a 2D table to store
		
		boolean IL[][] = new boolean[M + 1][N + 1];

		// IL is default initialised by false

		if ((M + N) != third.length())
			return false;

		// Process all characters of A and B

		for(int i = 0; i <= M; i++)
		{
			for(int j = 0; j <= N; j++)
			{
				
				// Two empty strings have an
				if (i == 0 && j == 0)
					IL[i][j] = true;

				// A is empty
				else if (i == 0)
				{
					if (second.charAt(j - 1) ==
							third.charAt(j - 1))
						IL[i][j] = IL[i][j - 1];
				}

				// B is empty
				else if (j == 0)
				{
					if (first.charAt(i - 1) ==
							third.charAt(i - 1))
						IL[i][j] = IL[i - 1][j];
				}

				// Current character of C matches
				// with current character of A,
				// but doesn't match with current
				// character if B
				else if (first.charAt(i - 1) ==
						third.charAt(i + j - 1) &&
						second.charAt(j - 1) !=
								third.charAt(i + j - 1))
					IL[i][j] = IL[i - 1][j];

				// Current character of C matches
				// with current character of B, but
				// doesn't match with current
				// character if A
				else if (first.charAt(i - 1) !=
						third.charAt(i + j - 1) &&
						second.charAt(j - 1) ==
								third.charAt(i + j - 1))
					IL[i][j] = IL[i][j - 1];

				// Current character of C matches
				// with that of both A and B
				else if (first.charAt(i - 1) ==
						third.charAt(i + j - 1) &&
						second.charAt(j - 1) ==
								third.charAt(i + j - 1))
					IL[i][j] = (IL[i - 1][j] ||
								IL[i][j - 1]);
			}
		}
		return IL[M][N];
	}

	// Function to run test cases Check if a String is a valid shuffle of two Strings
	static void test(String first, String second, String third)
	{
		if (isInterleaved(first, second, third))
			System.out.println(third + " is valid shuffle of " +first + " and " + second);
		else
			System.out.println(third + " is not a valid shuffle of " +first + " and " + second);
	}

	// Driver code
	public static void main(String[] args)
	{
		test("abc", "def", "dabecf");
		test("pqr", "lmno", "plmrqon");
	}
	}
